import { getAdvice, hazardLabel, buildAlertMessage } from "../../shared/adviceEngine.ts";

export default async function(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const { hazard, crop, stage, lang, villageName, level } = body;
    if (!hazard) return Response.json({ error: "hazard required" }, { status: 400 });
    const language = lang === "hi" ? "hi" : "en";
    const steps = getAdvice(hazard, crop || "Apple", stage || "Fruit setting", language);
    const message = buildAlertMessage(hazard, level || "HIGH", villageName || "your village", crop || "Apple", stage || "Fruit setting", language);
    return Response.json({
      hazard,
      label: hazardLabel(hazard, language),
      steps,
      message,
      lang: language
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}