import { scoreAll, levelFor, demoWeather, sampleWeatherResponse } from "../../shared/riskEngine.ts";
import { DISTRICTS } from "../../shared/villages.ts";

// Fetches weather for every village in a district in one Open-Meteo call
// (multi-location) and scores each village, to show the hyperlocal idea on the map.
export default async function(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const { district, crop, stage, demoScenario, lang } = body;
    const d = DISTRICTS.find((x) => x.name === district);
    if (!d) return Response.json({ error: "District not found" }, { status: 400 });

    const villages = d.villages;
    const month = new Date().getMonth() + 1;
    let weatherArr;
    let source = "open-meteo";

    if (demoScenario && demoScenario !== "off") {
      weatherArr = villages.map(() => demoWeather(demoScenario, month));
      source = "demo";
    } else {
      const lat = villages.map((v) => v.lat).join(",");
      const lon = villages.map((v) => v.lon).join(",");
      try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lon}` +
          `&current=temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation,cloud_cover,pressure_msl` +
          `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max` +
          `&timezone=auto&forecast_days=1`;
        const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
        if (!res.ok) throw new Error("Weather API " + res.status);
        const data = await res.json();
        weatherArr = Array.isArray(data) ? data : [data];
      } catch (_) {
        weatherArr = villages.map((vv) => sampleWeatherResponse(vv, month));
        source = "sample";
      }
    }

    const results = villages.map((v, i) => {
      const w = weatherArr[i];
      const cur = w.current || w;
      const weather = {
        tempMax: (w.daily?.temperature_2m_max?.[0]) ?? (cur.temperature_2m + 4),
        tempMin: (w.daily?.temperature_2m_min?.[0]) ?? (cur.temperature_2m - 6),
        humidity: cur.relative_humidity_2m ?? 70,
        wind: cur.wind_speed_10m ?? 8,
        rain: cur.precipitation ?? 0,
        cloudCover: cur.cloud_cover ?? 50,
        pressure: cur.pressure_msl ?? 1010,
        rainProb: w.daily?.precipitation_probability_max?.[0] || 30,
        month,
        altitude: v.altitude,
        slope: v.slope
      };
      const r = scoreAll(weather);
      let highest = { hazard: "frost", level: "LOW", percent: 0 };
      for (const h of ["hail", "frost", "landslide"]) {
        if (r[h].percent > highest.percent) highest = { hazard: h, level: r[h].level, percent: r[h].percent };
      }
      return {
        name: v.name,
        lat: v.lat,
        lon: v.lon,
        altitude: v.altitude,
        slope: v.slope,
        risk: r,
        highest
      };
    });

    const center = {
      lat: villages.reduce((s, v) => s + v.lat, 0) / villages.length,
      lon: villages.reduce((s, v) => s + v.lon, 0) / villages.length
    };

    return Response.json({ district, source, center, villages: results });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}