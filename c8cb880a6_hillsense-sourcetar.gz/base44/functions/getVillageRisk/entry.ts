import { scoreAll, featureImportance, MODEL_ACCURACY, levelFor, demoWeather, sampleWeatherResponse } from "../../shared/riskEngine.ts";
import { findVillage } from "../../shared/villages.ts";

const WEATHER_DESCRIPTION = (code) => {
  if (code === 0) return "Clear sky";
  if (code <= 2) return "Partly cloudy";
  if (code === 3) return "Overcast";
  if (code <= 48) return "Fog";
  if (code <= 57) return "Drizzle";
  if (code <= 67) return "Rain";
  if (code <= 77) return "Snow";
  if (code <= 82) return "Showers";
  if (code <= 86) return "Snow showers";
  if (code >= 95) return "Thunderstorm";
  return "Variable";
};

function monthOf(dateStr) {
  return new Date(dateStr).getMonth() + 1;
}

function dayLabel(dateStr, lang) {
  const d = new Date(dateStr);
  const en = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"][d.getDay()];
  const hi = ["रवि", "सोम", "मंगल", "बुध", "गुरु", "शुक्र", "शनि"][d.getDay()];
  const day = lang === "hi" ? hi : en;
  return `${day} ${d.getDate()}/${d.getMonth() + 1}`;
}

export default async function(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const { district, village, crop, stage, demoScenario, lang } = body;
    const v = findVillage(district, village);
    if (!v) return Response.json({ error: "Village not found" }, { status: 400 });

    const language = lang === "hi" ? "hi" : "en";
    const month = new Date().getMonth() + 1;
    let source = "open-meteo";
    let currentRaw;
    let daily;

    if (demoScenario && demoScenario !== "off") {
      const dw = demoWeather(demoScenario, month);
      currentRaw = {
        temperature_2m: dw.tempMax - 4,
        relative_humidity_2m: dw.humidity,
        wind_speed_10m: dw.wind,
        precipitation: dw.rain,
        cloud_cover: dw.cloudCover,
        pressure_msl: dw.pressure,
        weather_code: demoScenario === "frostnight" ? 1 : demoScenario === "heavyrain" ? 63 : 95
      };
      const today = new Date();
      daily = {
        time: [0, 1, 2, 3].map((i) => new Date(today.getTime() + i * 86400000).toISOString().slice(0, 10)),
        temperature_2m_max: [dw.tempMax, dw.tempMax - 3, dw.tempMax - 5, dw.tempMax - 2],
        temperature_2m_min: [dw.tempMin, dw.tempMin + 2, dw.tempMin + 3, dw.tempMin + 1],
        precipitation_sum: [dw.rain, dw.rain * 0.5, dw.rain * 0.2, 1],
        precipitation_probability_max: [dw.rainProb, dw.rainProb - 20, dw.rainProb - 40, 20],
        wind_speed_10m_max: [dw.wind, dw.wind - 4, dw.wind - 6, dw.wind - 2]
      };
      source = "demo";
    } else {
      try {
        const url = `https://api.open-meteo.com/v1/forecast?latitude=${v.lat}&longitude=${v.lon}` +
          `&current=temperature_2m,relative_humidity_2m,wind_speed_10m,precipitation,cloud_cover,pressure_msl,weather_code` +
          `&daily=temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_speed_10m_max` +
          `&timezone=auto&forecast_days=4`;
        const res = await fetch(url, { signal: AbortSignal.timeout(10000) });
        if (!res.ok) throw new Error("Weather API " + res.status);
        const data = await res.json();
        currentRaw = data.current;
        daily = data.daily;
      } catch (_) {
        const sample = sampleWeatherResponse(v, month);
        currentRaw = sample.current;
        daily = sample.daily;
        source = "sample";
      }
    }

    const cur = {
      temp: Math.round(currentRaw.temperature_2m),
      humidity: Math.round(currentRaw.relative_humidity_2m),
      wind: Math.round(currentRaw.wind_speed_10m),
      rain: +(currentRaw.precipitation || 0).toFixed(1),
      cloudCover: Math.round(currentRaw.cloud_cover || 0),
      pressure: Math.round(currentRaw.pressure_msl || 1010),
      weatherCode: currentRaw.weather_code ?? 1
    };

    const todayWeather = {
      tempMax: daily.temperature_2m_max[0],
      tempMin: daily.temperature_2m_min[0],
      humidity: cur.humidity,
      wind: cur.wind,
      rain: cur.rain,
      cloudCover: cur.cloudCover,
      pressure: cur.pressure,
      rainProb: daily.precipitation_probability_max[0] || 0,
      month,
      altitude: v.altitude,
      slope: v.slope
    };
    const risk = scoreAll(todayWeather);

    const forecast = [1, 2, 3].map((i) => {
      const w = {
        tempMax: daily.temperature_2m_max[i],
        tempMin: daily.temperature_2m_min[i],
        humidity: cur.humidity,
        wind: daily.wind_speed_10m_max[i],
        rain: daily.precipitation_sum[i],
        cloudCover: cur.cloudCover,
        pressure: cur.pressure,
        rainProb: daily.precipitation_probability_max[i] || 0,
        month: monthOf(daily.time[i]),
        altitude: v.altitude,
        slope: v.slope
      };
      const r = scoreAll(w);
      return {
        date: daily.time[i],
        label: dayLabel(daily.time[i], language),
        tmax: Math.round(w.tempMax),
        tmin: Math.round(w.tempMin),
        rain: +w.rain.toFixed(1),
        risk: { hail: r.hail, frost: r.frost, landslide: r.landslide }
      };
    });

    const hazards = ["hail", "frost", "landslide"];
    let highest = { hazard: "frost", level: "LOW", percent: 0 };
    for (const h of hazards) {
      if (risk[h].percent > highest.percent) highest = { hazard: h, level: risk[h].level, percent: risk[h].percent };
    }

    return Response.json({
      village: { name: v.name, district: v.district, lat: v.lat, lon: v.lon, altitude: v.altitude, slope: v.slope },
      source,
      isDemo: source === "demo",
      current: { ...cur, tempMin: Math.round(todayWeather.tempMin), tempMax: Math.round(todayWeather.tempMax), description: WEATHER_DESCRIPTION(cur.weatherCode) },
      risk,
      forecast,
      highest,
      modelInfo: { accuracy: MODEL_ACCURACY, featureImportance: featureImportance() }
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}