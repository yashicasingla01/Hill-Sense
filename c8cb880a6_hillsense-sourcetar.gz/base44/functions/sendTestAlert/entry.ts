// Simulated WhatsApp/SMS alert sender for the HillSense demo.
//
// To enable REAL sending later: set the app secrets TWILIO_ACCOUNT_SID,
// TWILIO_AUTH_TOKEN and TWILIO_WHATSAPP_FROM (from console.twilio.com), then
// POST to https://api.twilio.com/2010-04-01/Accounts/{sid}/Messages.json with
// Basic auth, body params From (whatsapp:<from>), To (whatsapp:<to>) and Body.

export default async function(req) {
  try {
    const body = await req.json().catch(() => ({}));
    const { to, message, channel } = body;
    if (!message) return Response.json({ error: "message required" }, { status: 400 });

    return Response.json({
      sent: false,
      simulated: true,
      channel: channel || "whatsapp",
      to: to || "(not provided)",
      preview: message,
      confirmation: "Message sent (simulated)"
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}