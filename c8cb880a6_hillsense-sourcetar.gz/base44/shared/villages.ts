// Village terrain data for Himachal Pradesh hill districts.
// lat/lon feed the Open-Meteo API; altitude (m) and slope (degrees) feed the risk model.
// Prototype dataset — values are representative, not survey-grade.

export const DISTRICTS = [
  {
    name: "Mandi",
    villages: [
      { name: "Mandi", lat: 31.71, lon: 76.73, altitude: 760, slope: 22 },
      { name: "Sundernagar", lat: 31.52, lon: 76.88, altitude: 900, slope: 18 },
      { name: "Joginder Nagar", lat: 31.99, lon: 76.78, altitude: 1220, slope: 34 }
    ]
  },
  {
    name: "Kullu",
    villages: [
      { name: "Kullu", lat: 31.96, lon: 77.11, altitude: 1200, slope: 35 },
      { name: "Naggar", lat: 32.13, lon: 77.17, altitude: 1760, slope: 40 },
      { name: "Banjar", lat: 31.63, lon: 77.35, altitude: 1400, slope: 38 }
    ]
  },
  {
    name: "Shimla",
    villages: [
      { name: "Shimla", lat: 31.10, lon: 77.17, altitude: 2200, slope: 30 },
      { name: "Theog", lat: 31.18, lon: 77.40, altitude: 2400, slope: 36 },
      { name: "Kotgarh", lat: 31.32, lon: 77.47, altitude: 2100, slope: 42 }
    ]
  },
  {
    name: "Kinnaur",
    villages: [
      { name: "Reckong Peo", lat: 31.58, lon: 78.45, altitude: 2290, slope: 48 },
      { name: "Kalpa", lat: 31.54, lon: 78.49, altitude: 2600, slope: 52 },
      { name: "Pooh", lat: 31.78, lon: 78.74, altitude: 2400, slope: 55 }
    ]
  },
  {
    name: "Chamba",
    villages: [
      { name: "Chamba", lat: 32.55, lon: 76.13, altitude: 1000, slope: 30 },
      { name: "Dalhousie", lat: 32.54, lon: 75.97, altitude: 1950, slope: 38 },
      { name: "Bharmour", lat: 32.99, lon: 76.65, altitude: 2100, slope: 44 }
    ]
  }
];

export const CROPS = ["Apple", "Cherry", "Plum", "Vegetables"];
export const STAGES = ["Flowering", "Fruit setting", "Harvest"];

export function findVillage(districtName, villageName) {
  const district = DISTRICTS.find((d) => d.name === districtName);
  if (!district) return null;
  const village = district.villages.find((v) => v.name === villageName);
  if (!village) return null;
  return { ...village, district: districtName };
}

export function allVillages() {
  const list = [];
  for (const d of DISTRICTS) {
    for (const v of d.villages) {
      list.push({ ...v, district: d.name });
    }
  }
  return list;
}