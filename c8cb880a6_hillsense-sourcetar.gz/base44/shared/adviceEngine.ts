// Crop-specific, stage-aware action advice in Hindi and English.
// Rules-based generator covering hazard x crop x stage. Language is kept
// simple and non-technical for low-literacy farmers.

const CROPS = ["Apple", "Cherry", "Plum", "Vegetables"];
const STAGES = ["Flowering", "Fruit setting", "Harvest"];

function frostSteps(crop, stage, lang) {
  const en = {
    Apple: {
      Flowering: ["Cover young plants and blossoms with cloth or plastic sheets", "Light smoke fires in the orchard before 10 PM", "Give light irrigation in the evening to hold warmth"],
      "Fruit setting": ["Cover young fruit clusters with paper caps", "Run sprinklers before dawn to protect from freezing", "Avoid pruning on frost nights"],
      Harvest: ["Harvest ripe fruit early before the frost night", "Cover harvested crates with a tarp", "Move produce to a sheltered store room"]
    },
    Cherry: {
      Flowering: ["Cover cherry trees with frost nets or cloth", "Light smudge pots / smoke fires before midnight", "Stop irrigation in the late evening"],
      "Fruit setting": ["Cover fruiting branches with plastic", "Keep wind machines or sprinklers running at dawn", "Do not spray during frost"],
      Harvest: ["Pick ripe cherries before nightfall", "Store harvest in a covered room", "Cover field crates with tarpaulin"]
    },
    Plum: {
      Flowering: ["Cover plum trees with cloth sheets", "Light smoke fires in the rows", "Light evening irrigation to keep ground warm"],
      "Fruit setting": ["Wrap young fruit branches", "Use sprinklers before sunrise", "Skip pruning on cold nights"],
      Harvest: ["Harvest mature plums early", "Cover crates and move indoors", "Keep fruit dry and covered"]
    },
    Vegetables: {
      Flowering: ["Cover beds with plastic mulch or row covers", "Water lightly in the evening", "Add dry straw over seedlings"],
      "Fruit setting": ["Cover fruiting plants with polythene at night", "Remove covers after sunrise", "Avoid wetting leaves at night"],
      Harvest: ["Harvest all mature vegetables before night", "Cover the rest with straw or plastic", "Store harvest in a covered shed"]
    }
  };
  const hi = {
    Apple: {
      Flowering: ["नन्हे पौधों और फूलों को कपड़े या प्लास्टिक से ढक दें", "रात 10 बजे से पहले बाग़ में धुआँ की आँखें जलाएँ", "शाम को हल्की सिंचाई करें ताकि ज़मीन गर्म रहे"],
      "Fruit setting": ["नन्हे फलों को कागज़ की टोपी से ढकें", "भोर से पहले स्प्रिंकलर चलाएँ ताकि फल जमे नहीं", "जाड़े की रात काट-छाँट न करें"],
      Harvest: ["पके फल जाड़े की रात से पहले तोड़ लें", "तोड़े हुए बक्सों को टर्पलिन से ढकें", "उपज को ढके हुए कमरे में रखें"]
    },
    Cherry: {
      Flowering: ["चेरी के पेड़ों को फ्रॉस्ट नेट या कपड़े से ढकें", "आधी रात से पहले धुआँ की आँखें जलाएँ", "शाम देर में सिंचाई बंद करें"],
      "Fruit setting": ["फलदार डालियों को प्लास्टिक से ढकें", "भोर पर विंड मशीन या स्प्रिंकलर चलाएँ", "जाड़े में स्प्रे न करें"],
      Harvest: ["पकी चेरी शाम से पहले तोड़ लें", "उपज को ढके कमरे में रखें", "मैदान के बक्सों को टर्पलिन से ढकें"]
    },
    Plum: {
      Flowering: ["प्लम के पेड़ों को कपड़े से ढकें", "कतारों में धुआँ की आँखें जलाएँ", "ज़मीन गर्म रखने शाम को हल्की सिंचाई"],
      "Fruit setting": ["नन्ही फलदार डालियों को लपेटें", "सूर्योदय पर स्प्रिंकलर चलाएँ", "ठंडी रात काट-छाँट न करें"],
      Harvest: ["पके प्लम जल्दी तोड़ लें", "बक्सों को ढककर अंदर ले जाएँ", "फल सूखे और ढके रखें"]
    },
    Vegetables: {
      Flowering: ["क्यारियों को प्लास्टिक मल्च या रो-कवर से ढकें", "शाम को हल्की सिंचाई करें", "पौधों पर सूखी भूसी डालें"],
      "Fruit setting": ["फलदार पौधों को रात प्लास्टिक से ढकें", "सुबह ढकना हटा दें", "रात को पत्ते गीले न करें"],
      Harvest: ["पकी सब्ज़ियाँ रात से पहले तोड़ लें", "बाकी को भूसी या प्लास्टिक से ढकें", "उपज को ढके शेड में रखें"]
    }
  };
  const table = lang === "hi" ? hi : en;
  return table[crop]?.[stage] || table.Apple["Fruit setting"];
}

function hailSteps(crop, stage, lang) {
  const en = {
    Apple: {
      Flowering: ["Spread hail nets over young trees if available", "Do not spray chemicals before the storm", "Check blossom damage once the storm passes"],
      "Fruit setting": ["Spread hail nets over the orchard", "Stop all spraying before the hail", "Inspect trees and remove damaged fruit after the storm"],
      Harvest: ["Harvest ripe fruit before the hail if time permits", "Cover stacked harvest with tarpaulin", "Sort and sell hail-hit fruit first after the storm"]
    },
    Cherry: {
      Flowering: ["Put hail nets over cherry trees", "Avoid spraying before the storm", "Assess blossom loss after the hail"],
      "Fruit setting": ["Cover fruiting trees with nets", "Stop spraying", "Remove bruised fruit after the storm to avoid rot"],
      Harvest: ["Pick ripe cherries before the storm if possible", "Cover harvest crates with tarp", "Sell hail-hit cherries quickly for processing"]
    },
    Plum: {
      Flowering: ["Hail nets over plum trees", "No spraying before the storm", "Check blossom damage after"],
      "Fruit setting": ["Nets over the orchard", "Stop spraying", "Cull bruised fruit after the storm"],
      Harvest: ["Harvest ripe plums before the storm", "Cover crates with tarp", "Process hail-hit fruit first"]
    },
    Vegetables: {
      Flowering: ["Cover vegetable beds with net or plastic", "Stop spraying", "Check seedling damage after the storm"],
      "Fruit setting": ["Cover fruiting plants with netting", "No spraying before hail", "Remove bruised produce after"],
      Harvest: ["Harvest mature vegetables before the storm", "Cover the rest with tarp", "Sell hail-hit produce quickly"]
    }
  };
  const hi = {
    Apple: {
      Flowering: ["नन्हे पेड़ों पर हेल नेट फैलाएँ यदि उपलब्ध हो", "आँधी से पहले कोई दवा न छिड़कें", "आँधी गुज़रने के बाद फूलों का नुकसान जाँचें"],
      "Fruit setting": ["बाग़ में हेल नेट फैलाएँ", "ओलों से पहले सारा स्प्रे बंद करें", "आँधी के बाद पेड़ जाँचकर फटे फल हटाएँ"],
      Harvest: ["समय हो तो पके फल ओलों से पहले तोड़ लें", "ढेर को टर्पलिन से ढकें", "ओलों से बाद फटे फल पहले बेचें"]
    },
    Cherry: {
      Flowering: ["चेरी पेड़ों पर हेल नेट लगाएँ", "आँधी से पहले स्प्रे न करें", "ओलों के बाद फूलों का नुकसान देखें"],
      "Fruit setting": ["फलदार पेड़ों को नेट से ढकें", "स्प्रे बंद करें", "सड़न से बचने फटे फल हटाएँ"],
      Harvest: ["ओलों से पहले पकी चेरी तोड़ लें", "बक्सों को टर्प से ढकें", "फटी चेरी जल्दी प्रोसेसिंग के लिए बेचें"]
    },
    Plum: {
      Flowering: ["प्लम पेड़ों पर हेल नेट", "आँधी से पहले स्प्रे न करें", "ओलों के बाद फूल जाँचें"],
      "Fruit setting": ["बाग़ में नेट लगाएँ", "स्प्रे बंद करें", "फटे फल ओलों के बाद हटाएँ"],
      Harvest: ["पके प्लम ओलों से पहले तोड़ लें", "बक्सों को टर्प से ढकें", "फटे फल पहले प्रोसेस करें"]
    },
    Vegetables: {
      Flowering: ["सब्ज़ी की क्यारियों को नेट या प्लास्टिक से ढकें", "स्प्रे बंद करें", "ओलों के बाद पौधे जाँचें"],
      "Fruit setting": ["फलदार पौधों को नेटिंग से ढकें", "ओलों से पहले स्प्रे न करें", "फटी सब्ज़ी हटाएँ"],
      Harvest: ["पकी सब्ज़ी ओलों से पहले तोड़ लें", "बाकी को टर्प से ढकें", "फटी उपज जल्दी बेचें"]
    }
  };
  const table = lang === "hi" ? hi : en;
  return table[crop]?.[stage] || table.Apple["Fruit setting"];
}

function landslideSteps(lang) {
  const en = [
    "Move equipment, tools and livestock away from steep slopes",
    "Avoid roads near hill cuttings and do not stop below loose banks",
    "Listen for local authority warnings and keep family indoors"
  ];
  const hi = [
    "उपकरण और मवेशी तीखी ढाल से दूर ले जाएँ",
    "कटे हुए पहाड़ी रास्तों से बचें और खुली मिट्टी के नीचे न रुकें",
    "स्थानीय चेतावनी सुनें और परिवार को घर के अंदर रखें"
  ];
  return lang === "hi" ? hi : en;
}

export function getAdvice(hazard, crop, stage, lang) {
  const safeCrop = CROPS.includes(crop) ? crop : "Apple";
  const safeStage = STAGES.includes(stage) ? stage : "Fruit setting";
  if (hazard === "frost") return frostSteps(safeCrop, safeStage, lang);
  if (hazard === "hail") return hailSteps(safeCrop, safeStage, lang);
  if (hazard === "landslide") return landslideSteps(lang);
  return [];
}

export function hazardLabel(hazard, lang) {
  if (lang === "hi") {
    if (hazard === "frost") return "बारिश की ठंड (फ्रॉस्ट)";
    if (hazard === "hail") return "ओले (हेल)";
    if (hazard === "landslide") return "भूस्खलन";
  }
  if (hazard === "frost") return "Frost";
  if (hazard === "hail") return "Hail";
  if (hazard === "landslide") return "Landslide";
  return hazard;
}

export function buildAlertMessage(hazard, level, villageName, crop, stage, lang) {
  const steps = getAdvice(hazard, crop, stage, lang);
  const label = hazardLabel(hazard, lang);
  const levelWord = lang === "hi"
    ? (level === "HIGH" ? "लाल अलर्ट" : level === "MEDIUM" ? "पीला अलर्ट" : "हरा अलर्ट")
    : (level === "HIGH" ? "RED ALERT" : level === "MEDIUM" ? "AMBER ALERT" : "GREEN ALERT");
  const head = `${levelWord}: ${label} — ${villageName}`;
  const body = steps.map((s, i) => `${i + 1}. ${s}`).join("\n");
  return `${head}\n${body}`;
}