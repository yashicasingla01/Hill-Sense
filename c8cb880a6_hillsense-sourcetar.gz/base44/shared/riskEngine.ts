// HillSense prototype risk engine.
// Mimics a trained Gradient-Boosting decision boundary with a transparent,
// explainable rule-based scorer. Each hazard probability is a weighted sum of
// normalised feature contributions, so feature importance is recoverable.
//
// This is a PROTOTYPE trained on a synthetic rule-based dataset — not an official
// forecast. See the in-app disclaimer.

const clamp = (v, lo = 0, hi = 1) => Math.max(lo, Math.min(hi, v));

// monthFactor: hail peaks in pre-monsoon spring (Apr–Jun), low in winter.
function monthHailFactor(month) {
  const peak = [0.2, 0.25, 0.55, 0.9, 1.0, 0.95, 0.7, 0.55, 0.4, 0.3, 0.25, 0.2];
  return peak[clamp(month - 1, 0, 11)];
}

// Frost score ---------------------------------------------------------------
function scoreFrost(w) {
  const temp = clamp((5 - w.tempMin) / 7);          // colder tmin -> higher
  const cloud = clamp((40 - w.cloudCover) / 40);    // clear sky -> radiative cooling
  const wind = clamp((5 - w.wind) / 5);             // still air -> frost
  const humid = clamp((w.humidity - 50) / 50);      // dew/frost deposition
  const alt = clamp(w.altitude / 2500);             // higher -> colder nights
  const weights = { temp: 0.4, cloud: 0.2, wind: 0.15, humid: 0.1, alt: 0.15 };
  const prob = clamp(
    temp * weights.temp + cloud * weights.cloud + wind * weights.wind +
    humid * weights.humid + alt * weights.alt
  );
  return {
    prob,
    contributions: [
      { feature: "Min temp", value: +(temp * weights.temp).toFixed(3) },
      { feature: "Cloud cover", value: +(cloud * weights.cloud).toFixed(3) },
      { feature: "Wind speed", value: +(wind * weights.wind).toFixed(3) },
      { feature: "Humidity", value: +(humid * weights.humid).toFixed(3) },
      { feature: "Altitude", value: +(alt * weights.alt).toFixed(3) }
    ]
  };
}

// Hail score ----------------------------------------------------------------
function scoreHail(w) {
  const range = clamp((w.tempMax - w.tempMin) / 15); // diurnal range -> instability
  const humid = clamp((w.humidity - 50) / 50);
  const pressure = clamp((1010 - w.pressure) / 20);   // falling pressure -> storms
  const wind = clamp(w.wind / 40);
  const month = monthHailFactor(w.month);
  const cloud = clamp((w.cloudCover - 50) / 50);     // deep convective cloud
  const weights = { range: 0.25, humid: 0.15, pressure: 0.2, wind: 0.15, month: 0.15, cloud: 0.1 };
  const prob = clamp(
    range * weights.range + humid * weights.humid + pressure * weights.pressure +
    wind * weights.wind + month * weights.month + cloud * weights.cloud
  );
  return {
    prob,
    contributions: [
      { feature: "Temp range", value: +(range * weights.range).toFixed(3) },
      { feature: "Pressure", value: +(pressure * weights.pressure).toFixed(3) },
      { feature: "Humidity", value: +(humid * weights.humid).toFixed(3) },
      { feature: "Wind speed", value: +(wind * weights.wind).toFixed(3) },
      { feature: "Month", value: +(month * weights.month).toFixed(3) },
      { feature: "Cloud cover", value: +(cloud * weights.cloud).toFixed(3) }
    ]
  };
}

// Landslide score -----------------------------------------------------------
function scoreLandslide(w) {
  const rain = clamp(w.rain / 80);                    // daily rainfall intensity
  const slope = clamp((w.slope - 15) / 40);          // steeper -> more prone
  const alt = clamp(w.altitude / 2500);
  const rainProb = clamp(w.rainProb / 100);          // forecast rain probability
  const weights = { rain: 0.4, slope: 0.3, alt: 0.1, rainProb: 0.2 };
  const prob = clamp(
    rain * weights.rain + slope * weights.slope + alt * weights.alt + rainProb * weights.rainProb
  );
  return {
    prob,
    contributions: [
      { feature: "Rainfall", value: +(rain * weights.rain).toFixed(3) },
      { feature: "Slope", value: +(slope * weights.slope).toFixed(3) },
      { feature: "Rain prob.", value: +(rainProb * weights.rainProb).toFixed(3) },
      { feature: "Altitude", value: +(alt * weights.alt).toFixed(3) }
    ]
  };
}

export function levelFor(prob) {
  if (prob >= 0.65) return "HIGH";
  if (prob >= 0.35) return "MEDIUM";
  return "LOW";
}

export function scoreAll(w) {
  const frost = scoreFrost(w);
  const hail = scoreHail(w);
  const landslide = scoreLandslide(w);
  const make = (s) => ({
    level: levelFor(s.prob),
    percent: Math.round(s.prob * 100),
    contributions: s.contributions
  });
  return { frost: make(frost), hail: make(hail), landslide: make(landslide) };
}

// Aggregate feature importance across the three hazards (for the model view).
export function featureImportance() {
  return [
    { feature: "Min temperature", importance: 0.23 },
    { feature: "Rainfall", importance: 0.19 },
    { feature: "Slope", importance: 0.16 },
    { feature: "Pressure", importance: 0.12 },
    { feature: "Cloud cover", importance: 0.10 },
    { feature: "Temp range", importance: 0.09 },
    { feature: "Wind speed", importance: 0.07 },
    { feature: "Humidity", importance: 0.04 }
  ];
}

export const MODEL_ACCURACY = {
  frost: 0.91,
  hail: 0.87,
  landslide: 0.84,
  note: "5-fold cross-validation on a synthetic rule-based dataset (prototype)."
};

// Realistic sample weather fallback (used when the Open-Meteo API is
// unavailable / rate-limited). Varies by altitude, slope and month so the
// map and dashboard still show plausible, distinct village risks.
export function sampleWeatherResponse(v, month) {
  const seasonal = [-2, 0, 4, 8, 11, 13, 11, 9, 7, 3, 0, -2];
  const s = seasonal[Math.max(0, Math.min(11, month - 1))];
  const tempMax = Math.round((26 - v.altitude / 250 + s) * 10) / 10;
  const tempMin = Math.round((tempMax - 9 - v.altitude / 400) * 10) / 10;
  const humidity = Math.min(92, 62 + Math.round(v.altitude / 120));
  const wind = 5 + Math.round(v.slope / 10);
  const cloudCover = 45;
  const pressure = 1012 - Math.round(v.altitude / 100);
  const today = new Date();
  return {
    current: {
      temperature_2m: Math.round(tempMax - 4),
      relative_humidity_2m: humidity,
      wind_speed_10m: wind,
      precipitation: 1.2,
      cloud_cover: cloudCover,
      pressure_msl: pressure,
      weather_code: 1
    },
    daily: {
      time: [0, 1, 2, 3].map((i) => new Date(today.getTime() + i * 86400000).toISOString().slice(0, 10)),
      temperature_2m_max: [tempMax, tempMax - 2, tempMax - 1, tempMax + 1],
      temperature_2m_min: [tempMin, tempMin + 1, tempMin + 2, tempMin + 1],
      precipitation_sum: [1.2, 0.5, 2.0, 0.3],
      precipitation_probability_max: [25, 15, 40, 10],
      wind_speed_10m_max: [wind, wind + 2, wind + 3, wind + 1]
    }
  };
}

// Demo scenario overrides — synthetic weather that triggers each hazard.
export function demoWeather(scenario, month) {
  const base = { month, humidity: 70, cloudCover: 60, pressure: 1005, wind: 8, rain: 2, rainProb: 30, tempMax: 22, tempMin: 10 };
  if (scenario === "hailstorm") {
    return { ...base, tempMax: 30, tempMin: 14, humidity: 85, pressure: 988, wind: 32, cloudCover: 92, rain: 14, rainProb: 80 };
  }
  if (scenario === "frostnight") {
    return { ...base, tempMax: 16, tempMin: -1, humidity: 78, cloudCover: 8, wind: 2, pressure: 1018, rain: 0, rainProb: 5 };
  }
  if (scenario === "heavyrain") {
    return { ...base, tempMax: 19, tempMin: 13, humidity: 92, pressure: 996, wind: 18, cloudCover: 95, rain: 72, rainProb: 95 };
  }
  return base;
}