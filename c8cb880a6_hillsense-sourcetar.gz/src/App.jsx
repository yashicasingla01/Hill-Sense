import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import ScrollToTop from './components/ScrollToTop';
import { AppProvider } from '@/lib/AppContext';
import Root from './pages/Root';
import Dashboard from './pages/Dashboard';
import AlertDetail from './pages/AlertDetail';
import Forecast from './pages/Forecast';
import WhatsAppPreview from './pages/WhatsAppPreview';
import AlertHistory from './pages/AlertHistory';
import RiskMap from './pages/RiskMap';
import Impact from './pages/Impact';
import ModelInfo from './pages/ModelInfo';
import Settings from './pages/Settings';
// Add page imports here

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={<Root />} />
      <Route path="/dashboard" element={<Dashboard />} />
      <Route path="/alert/:hazard" element={<AlertDetail />} />
      <Route path="/forecast" element={<Forecast />} />
      <Route path="/whatsapp" element={<WhatsAppPreview />} />
      <Route path="/history" element={<AlertHistory />} />
      <Route path="/map" element={<RiskMap />} />
      <Route path="/impact" element={<Impact />} />
      <Route path="/model" element={<ModelInfo />} />
      <Route path="/settings" element={<Settings />} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <ScrollToTop />
          <AppProvider>
            <AuthenticatedApp />
          </AppProvider>
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App