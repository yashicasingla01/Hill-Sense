import React, { useState, useEffect } from 'react';
import { useApp } from '@/lib/AppContext';
import { useVillageRisk } from '@/lib/useVillageRisk';
import { t } from '@/lib/i18n';
import { base44 } from '@/api/base44Client';
import AppShell from '@/components/hillsense/AppShell';
import Logo from '@/components/hillsense/Logo';
import { Send, Check, Phone, MessageCircle, Info } from 'lucide-react';

export default function WhatsAppPreview() {
  const { language, district, village, crop, stage, demoScenario } = useApp();
  const lang = language;
  const { data } = useVillageRisk({ district, village, crop, stage, demoScenario, lang });
  const [advice, setAdvice] = useState(null);
  const [phone, setPhone] = useState('');
  const [status, setStatus] = useState(null);
  const [sending, setSending] = useState(false);

  const hazard = data?.highest?.hazard || 'frost';
  const level = data?.highest?.level || 'HIGH';

  useEffect(() => {
    if (!village) return;
    base44.functions.invoke('getAlertAdvice', { hazard, crop, stage, lang, villageName: village, level })
      .then((r) => setAdvice(r.data)).catch(() => {});
  }, [hazard, crop, stage, lang, village, level]);

  const handleSend = async () => {
    if (!advice?.message) return;
    setSending(true);
    setStatus(null);
    try {
      const res = await base44.functions.invoke('sendTestAlert', {
        to: phone || '',
        message: advice.message,
        channel: 'whatsapp'
      });
      setStatus(res.data);
    } catch (e) {
      setStatus({ confirmation: 'Error: ' + (e.message || 'failed'), simulated: true });
    } finally {
      setSending(false);
    }
  };

  const now = new Date();
  const time = now.toLocaleTimeString(lang === 'hi' ? 'hi-IN' : 'en-IN', { hour: '2-digit', minute: '2-digit' });

  return (
    <AppShell title="WhatsApp / SMS" subtitle={t('alertHistory', lang) === 'Alert history' ? 'Alert preview' : ''}>
      <div className="space-y-4">
        <div className="bg-hill-blue/10 border border-hill-blue/20 rounded-2xl p-3 flex gap-2 text-xs text-hill-deep">
          <Info size={16} className="shrink-0 mt-0.5" />
          <span>{lang === 'hi' ? 'यह अलर्ट किसान के फ़ोन पर WhatsApp या SMS से कैसे पहुँगा — नीचे दिख रहा है। असली भेजने के लिए Twilio कुंजी चाहिए, वरना यह अनुकरण (simulate) होता है।' : 'This is how the alert reaches the farmer on WhatsApp / SMS. Real sending needs a Twilio key; otherwise it is simulated.'}</span>
        </div>

        {/* WhatsApp mockup */}
        <div className="rounded-3xl overflow-hidden shadow-lg border border-hill-cream">
          <div className="bg-hill-deep px-4 py-3 flex items-center gap-3 text-white">
            <div className="w-10 h-10 rounded-full bg-white/15 flex items-center justify-center"><Logo size={22} /></div>
            <div>
              <div className="font-bold text-sm">HillSense Alerts</div>
              <div className="text-[11px] text-white/70">{lang === 'hi' ? 'ऑनलाइन' : 'online'}</div>
            </div>
          </div>
          <div className="bg-[#E5DDD5] p-4 min-h-[220px]" style={{ backgroundImage: 'radial-gradient(rgba(255,255,255,0.25) 1px, transparent 1px)', backgroundSize: '16px 16px' }}>
            <div className="bg-[#DCF8C7] rounded-2xl rounded-tl-sm p-3 shadow-sm max-w-[90%]">
              <p className="text-sm text-hill-deep whitespace-pre-line font-medium leading-relaxed">{advice?.message || '…'}</p>
              <div className="text-[10px] text-right text-hill-deep/60 mt-1 flex items-center justify-end gap-1">
                {time} <Check size={12} />
              </div>
            </div>
            <div className="bg-white rounded-2xl rounded-tl-sm p-3 shadow-sm max-w-[80%] mt-2">
              <p className="text-sm text-hill-deep">{lang === 'hi' ? 'कल ओलों का जोखिम कम है।' : 'Hail risk is low tomorrow.'}</p>
              <div className="text-[10px] text-right text-muted-foreground mt-1">{time}</div>
            </div>
          </div>
        </div>

        {/* Send controls */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream space-y-3">
          <label className="text-xs font-bold text-hill-deep uppercase tracking-wide flex items-center gap-1.5"><Phone size={14} /> {lang === 'hi' ? 'फ़ोन नंबर (वैकल्पिक)' : 'Phone number (optional)'}</label>
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="+91XXXXXXXXXX"
            className="w-full rounded-xl py-3 px-4 font-medium text-hill-deep bg-hill-cream border-2 border-transparent focus:border-hill-green outline-none transition"
          />
          <button
            onClick={handleSend}
            disabled={sending || !advice}
            className="w-full rounded-2xl py-4 bg-hill-green text-white font-bold text-base flex items-center justify-center gap-2 active:scale-[0.99] transition disabled:opacity-50"
          >
            {sending ? <span className="animate-pulse">{lang === 'hi' ? 'भेज रहे…' : 'Sending…'}</span> : <><Send size={20} /> {t('sendTestAlert', lang)}</>}
          </button>
          {status && (
            <div className={`rounded-xl p-3 text-sm font-semibold flex items-center gap-2 ${status.simulated ? 'bg-amber-50 text-amber-800' : 'bg-hill-low/15 text-hill-deep'}`}>
              <Check size={18} /> {status.confirmation}
              {status.simulated && <span className="text-xs font-normal">· {lang === 'hi' ? 'अनुकरण' : 'simulated'}</span>}
            </div>
          )}
        </div>

        <p className="text-[11px] text-muted-foreground text-center px-2">{t('disclaimer', lang)}</p>
      </div>
    </AppShell>
  );
}