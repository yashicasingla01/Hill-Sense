import React from 'react';
import { useNavigate } from 'react-router-dom';
import AppShell from '@/components/hillsense/AppShell';
import WeatherStrip from '@/components/hillsense/WeatherStrip';
import RiskPill from '@/components/hillsense/RiskPill';
import { useApp } from '@/lib/AppContext';
import { useVillageRisk } from '@/lib/useVillageRisk';
import { t } from '@/lib/i18n';
import { CloudHail, Snowflake, Mountain, ChevronRight, AlertTriangle, MessageCircle, RefreshCw, MapPin } from 'lucide-react';

const HAZARDS = [
  { key: 'hail', icon: CloudHail, color: 'text-hill-blue', bg: 'bg-hill-blue/10' },
  { key: 'frost', icon: Snowflake, color: 'text-hill-blue', bg: 'bg-hill-blue/10' },
  { key: 'landslide', icon: Mountain, color: 'text-amber-600', bg: 'bg-amber-50' }
];

const HAZARD_LABEL = { hail: { hi: 'ओले (हेल)', en: 'Hail' }, frost: { hi: 'जाड़ा (फ्रॉस्ट)', en: 'Frost' }, landslide: { hi: 'भूस्खलन', en: 'Landslide' } };

export default function Dashboard() {
  const { language, district, village, crop, stage, demoScenario } = useApp();
  const lang = language;
  const navigate = useNavigate();
  const { data, loading, error, refetch } = useVillageRisk({ district, village, crop, stage, demoScenario, lang });

  const highest = data?.highest;
  const showAlertCta = highest && (highest.level === 'HIGH' || highest.level === 'MEDIUM');

  return (
    <AppShell title={village ? `${village} village` : t('appName', lang)} subtitle={`${crop} · ${stage}`}>
      <div className="space-y-4">
        {/* Demo / source banner */}
        {data?.isDemo && (
          <div className="bg-amber-50 border border-amber-200 rounded-2xl px-3 py-2 text-amber-800 text-xs font-semibold flex items-center gap-2">
            <AlertTriangle size={15} /> {lang === 'hi' ? 'डेमो परिदृश्य चल रहा है — असली मौसम नहीं' : 'Demo scenario running — not real weather'}
          </div>
        )}

        {/* Current weather */}
        <section>
          <div className="flex items-center justify-between mb-2">
            <h2 className="font-bold text-hill-deep text-sm uppercase tracking-wide">{t('currentWeather', lang)}</h2>
            <button onClick={refetch} className="text-muted-foreground p-1"><RefreshCw size={16} /></button>
          </div>
          {loading ? (
            <div className="grid grid-cols-4 gap-2">
              {[0, 1, 2, 3].map((i) => <div key={i} className="h-20 rounded-2xl bg-hill-cream animate-pulse" />)}
            </div>
          ) : error ? (
            <div className="bg-destructive/10 text-destructive rounded-2xl p-3 text-sm">{error}</div>
          ) : data ? (
            <>
              <WeatherStrip current={data.current} lang={lang} />
              <div className="text-xs text-muted-foreground mt-1.5 flex items-center gap-1">
                <MapPin size={11} /> {data.village.district} · {data.village.altitude}m · {data.current.description}
                {data.source === 'sample' && <span className="ml-1 text-amber-600">(sample data)</span>}
              </div>
            </>
          ) : null}
        </section>

        {/* Today's risk */}
        <section>
          <h2 className="font-bold text-hill-deep text-sm uppercase tracking-wide mb-2">{t('todaysRisk', lang)}</h2>
          {loading ? (
            <div className="space-y-2">{[0, 1, 2].map((i) => <div key={i} className="h-24 rounded-2xl bg-hill-cream animate-pulse" />)}</div>
          ) : data ? (
            <div className="space-y-2.5">
              {HAZARDS.map((h) => {
                const r = data.risk[h.key];
                const Icon = h.icon;
                return (
                  <button
                    key={h.key}
                    onClick={() => navigate(`/alert/${h.key}`)}
                    className="w-full bg-white rounded-2xl p-4 shadow-sm border border-hill-cream flex items-center gap-3 text-left active:scale-[0.99] transition"
                  >
                    <div className={`w-12 h-12 rounded-2xl ${h.bg} flex items-center justify-center shrink-0`}>
                      <Icon size={26} className={h.color} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-bold text-hill-deep">{HAZARD_LABEL[h.key][lang]}</div>
                      <div className="flex items-center gap-2 mt-1">
                        <div className="flex-1 h-2 rounded-full bg-hill-cream overflow-hidden">
                          <div
                            className={`h-full rounded-full ${r.level === 'HIGH' ? 'bg-hill-high' : r.level === 'MEDIUM' ? 'bg-hill-medium' : 'bg-hill-low'}`}
                            style={{ width: `${Math.max(r.percent, 6)}%` }}
                          />
                        </div>
                        <span className="text-sm font-bold text-hill-deep w-9 text-right">{r.percent}%</span>
                      </div>
                    </div>
                    <RiskPill level={r.level} lang={lang} />
                    <ChevronRight size={18} className="text-muted-foreground" />
                  </button>
                );
              })}
            </div>
          ) : null}
        </section>

        {/* Alert CTA */}
        {showAlertCta && (
          <button
            onClick={() => navigate(`/alert/${highest.hazard}`)}
            className={`w-full rounded-2xl p-4 text-white font-bold flex items-center gap-3 shadow-lg animate-pop-in ${highest.level === 'HIGH' ? 'bg-hill-high' : 'bg-hill-medium'}`}
          >
            <AlertTriangle size={24} />
            <div className="flex-1 text-left">
              <div className="text-sm opacity-90">{lang === 'hi' ? 'सक्रिय अलर्ट' : 'Active alert'}</div>
              <div>{HAZARD_LABEL[highest.hazard][lang]} · {t(highest.level.toLowerCase(), lang)}</div>
            </div>
            <ChevronRight size={22} />
          </button>
        )}

        {/* Forecast + WhatsApp quick links */}
        <div className="grid grid-cols-2 gap-2.5">
          <button onClick={() => navigate('/forecast')} className="bg-white rounded-2xl p-3.5 shadow-sm border border-hill-cream text-left active:scale-[0.99] transition">
            <div className="text-xs text-muted-foreground">{t('forecast', lang)}</div>
            <div className="font-bold text-hill-deep text-sm flex items-center gap-1 mt-0.5">{t('tapForForecast', lang)}</div>
          </button>
          <button onClick={() => navigate('/whatsapp')} className="bg-hill-green rounded-2xl p-3.5 text-white text-left shadow-sm active:scale-[0.99] transition">
            <div className="text-xs text-white/80">WhatsApp</div>
            <div className="font-bold text-sm flex items-center gap-1 mt-0.5"><MessageCircle size={15} /> {lang === 'hi' ? 'अलर्ट झलक' : 'Alert preview'}</div>
          </button>
        </div>

        <p className="text-[11px] text-muted-foreground text-center leading-relaxed px-2">{t('disclaimer', lang)}</p>
      </div>
    </AppShell>
  );
}