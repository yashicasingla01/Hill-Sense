import React from 'react';
import AppShell from '@/components/hillsense/AppShell';
import RiskPill from '@/components/hillsense/RiskPill';
import { useApp } from '@/lib/AppContext';
import { t } from '@/lib/i18n';
import { CloudHail, Snowflake, Mountain, Trash2, Bell } from 'lucide-react';

const HAZARD_ICON = { hail: CloudHail, frost: Snowflake, landslide: Mountain };
const HAZARD_LABEL = { hail: { hi: 'ओले', en: 'Hail' }, frost: { hi: 'जाड़ा', en: 'Frost' }, landslide: { hi: 'भूस्खलन', en: 'Landslide' } };

export default function AlertHistory() {
  const { language, history, clearHistory } = useApp();
  const lang = language;

  return (
    <AppShell title={t('alertHistory', lang)}>
      <div className="space-y-3">
        {history.length === 0 ? (
          <div className="bg-white rounded-2xl p-10 text-center shadow-sm border border-hill-cream mt-6">
            <Bell size={40} className="mx-auto text-hill-cream mb-3" />
            <p className="text-muted-foreground font-medium">{t('noAlerts', lang)}</p>
            <p className="text-xs text-muted-foreground mt-1">{lang === 'hi' ? 'जोखिम बढ़ने पर अलर्ट यहाँ दिखेंगे।' : 'Alerts will appear here when risk rises.'}</p>
          </div>
        ) : (
          <>
            {history.map((a) => {
              const Icon = HAZARD_ICON[a.hazard] || Bell;
              const date = new Date(a.date);
              return (
                <div key={a.id} className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream flex items-center gap-3">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center shrink-0 ${a.level === 'HIGH' ? 'bg-hill-high/15' : 'bg-hill-medium/15'}`}>
                    <Icon size={22} className={a.level === 'HIGH' ? 'text-hill-high' : 'text-hill-medium'} />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="font-bold text-hill-deep">{HAZARD_LABEL[a.hazard]?.[lang] || a.hazard}</div>
                    <div className="text-xs text-muted-foreground">
                      {date.toLocaleDateString(lang === 'hi' ? 'hi-IN' : 'en-IN')} · {date.toLocaleTimeString(lang === 'hi' ? 'hi-IN' : 'en-IN', { hour: '2-digit', minute: '2-digit' })}
                    </div>
                    <div className="text-xs text-muted-foreground truncate">{a.village} · {a.crop}</div>
                  </div>
                  <div className="text-right">
                    <RiskPill level={a.level} lang={lang} size="sm" />
                    <div className="text-xs font-bold text-hill-deep mt-1">{a.percent}%</div>
                  </div>
                </div>
              );
            })}
            <button
              onClick={clearHistory}
              className="w-full rounded-2xl py-3 mt-2 border-2 border-destructive/30 text-destructive font-semibold text-sm flex items-center justify-center gap-2 active:scale-[0.99] transition"
            >
              <Trash2 size={16} /> {lang === 'hi' ? 'इतिहास साफ़ करें' : 'Clear history'}
            </button>
          </>
        )}
        <p className="text-[11px] text-muted-foreground text-center px-2 pt-2">{t('disclaimer', lang)}</p>
      </div>
    </AppShell>
  );
}