import React from 'react';
import AppShell from '@/components/hillsense/AppShell';
import RiskPill from '@/components/hillsense/RiskPill';
import { useApp } from '@/lib/AppContext';
import { useVillageRisk } from '@/lib/useVillageRisk';
import { t } from '@/lib/i18n';
import { CloudHail, Snowflake, Mountain } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const HAZARDS = [
  { key: 'hail', icon: CloudHail, color: '#2980B9' },
  { key: 'frost', icon: Snowflake, color: '#5D95B3' },
  { key: 'landslide', icon: Mountain, color: '#F39C12' }
];
const HAZARD_LABEL = { hail: { hi: 'ओले', en: 'Hail' }, frost: { hi: 'जाड़ा', en: 'Frost' }, landslide: { hi: 'भूस्खलन', en: 'Landslide' } };
const LEVEL_COLOR = { LOW: '#2E7D50', MEDIUM: '#F39C12', HIGH: '#E74C3C' };

export default function Forecast() {
  const { language, district, village, crop, stage, demoScenario } = useApp();
  const lang = language;
  const { data, loading } = useVillageRisk({ district, village, crop, stage, demoScenario, lang });

  const chartData = (data?.forecast || []).map((d) => ({
    day: d.label,
    Hail: d.risk.hail.percent,
    Frost: d.risk.frost.percent,
    Landslide: d.risk.landslide.percent
  }));

  return (
    <AppShell title={t('forecast', lang)} subtitle={village}>
      <div className="space-y-4">
        {loading || !data ? (
          <div className="space-y-3">{[0, 1, 2].map((i) => <div key={i} className="h-28 rounded-2xl bg-hill-cream animate-pulse" />)}</div>
        ) : (
          <>
            {/* Chart */}
            <div className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream">
              <h2 className="font-bold text-hill-deep text-sm mb-3">{lang === 'hi' ? '3-दिन जोखिम प्रवृत्ति' : '3-day risk trend'}</h2>
              <div className="h-52">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={chartData} barGap={2} margin={{ top: 5, right: 5, left: -22, bottom: 0 }}>
                    <XAxis dataKey="day" tick={{ fontSize: 11, fill: '#6b7280' }} axisLine={false} tickLine={false} />
                    <YAxis domain={[0, 100]} tick={{ fontSize: 10, fill: '#6b7280' }} axisLine={false} tickLine={false} />
                    <Tooltip cursor={{ fill: 'rgba(0,0,0,0.04)' }} contentStyle={{ borderRadius: 12, border: 'none', fontSize: 12 }} />
                    {HAZARDS.map((h) => (
                      <Bar key={h.key} dataKey={HAZARD_LABEL[h.key].en} fill={h.color} radius={[4, 4, 0, 0]} maxBarSize={22} />
                    ))}
                  </BarChart>
                </ResponsiveContainer>
              </div>
              <div className="flex justify-center gap-3 mt-1">
                {HAZARDS.map((h) => (
                  <div key={h.key} className="flex items-center gap-1 text-[11px] text-muted-foreground">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ background: h.color }} /> {HAZARD_LABEL[h.key][lang]}
                  </div>
                ))}
              </div>
            </div>

            {/* Day cards */}
            <div className="space-y-2.5">
              {data.forecast.map((d) => (
                <div key={d.date} className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream">
                  <div className="flex items-center justify-between mb-3">
                    <div className="font-bold text-hill-deep">{d.label}</div>
                    <div className="text-xs text-muted-foreground">{d.tmin}°–{d.tmax}°C · {d.rain}mm</div>
                  </div>
                  <div className="space-y-2">
                    {HAZARDS.map((h) => {
                      const r = d.risk[h.key];
                      const Icon = h.icon;
                      return (
                        <div key={h.key} className="flex items-center gap-2.5">
                          <Icon size={18} style={{ color: h.color }} />
                          <span className="text-sm font-medium text-hill-deep flex-1">{HAZARD_LABEL[h.key][lang]}</span>
                          <div className="w-20 h-1.5 rounded-full bg-hill-cream overflow-hidden">
                            <div className="h-full rounded-full" style={{ width: `${Math.max(r.percent, 5)}%`, background: LEVEL_COLOR[r.level] }} />
                          </div>
                          <span className="text-xs font-bold w-8 text-right" style={{ color: LEVEL_COLOR[r.level] }}>{r.percent}%</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </div>
          </>
        )}
        <p className="text-[11px] text-muted-foreground text-center px-2">{t('disclaimer', lang)}</p>
      </div>
    </AppShell>
  );
}