import React from 'react';
import { useNavigate } from 'react-router-dom';
import AppShell from '@/components/hillsense/AppShell';
import { useApp } from '@/lib/AppContext';
import { t, LANGS } from '@/lib/i18n';
import { Type, Globe, MapPin, Trash2, Info, ChevronRight, ShieldAlert } from 'lucide-react';

export default function Settings() {
  const { language, largeText, update, resetSetup, history, clearHistory } = useApp();
  const lang = language;
  const navigate = useNavigate();

  return (
    <AppShell title={t('settings', lang)}>
      <div className="space-y-4">
        {/* Language */}
        <Card icon={<Globe size={18} />} title={t('chooseLanguage', lang)}>
          <div className="grid grid-cols-2 gap-2">
            {LANGS.map((l) => {
              const active = language === l.code;
              return (
                <button key={l.code} onClick={() => update({ language: l.code })} className={`rounded-xl py-2.5 font-bold border-2 transition ${active ? 'bg-hill-deep text-white border-hill-deep' : 'bg-hill-cream text-hill-deep border-transparent'}`}>
                  <div>{l.label}</div>
                  <div className={`text-[11px] ${active ? 'text-white/70' : 'text-muted-foreground'}`}>{l.sub}</div>
                </button>
              );
            })}
          </div>
        </Card>

        {/* Large text */}
        <Card icon={<Type size={18} />} title={t('largeText', lang)}>
          <button onClick={() => update({ largeText: !largeText })} className="flex items-center justify-between w-full">
            <span className="text-sm font-medium text-hill-deep">{lang === 'hi' ? 'बड़े अक्षर चालू करें' : 'Enable large text'}</span>
            <span className={`w-12 h-7 rounded-full p-0.5 transition ${largeText ? 'bg-hill-green' : 'bg-muted'}`}>
              <span className={`block w-6 h-6 rounded-full bg-white transition-transform ${largeText ? 'translate-x-5' : ''}`} />
            </span>
          </button>
        </Card>

        {/* Change setup */}
        <button onClick={() => { resetSetup(); navigate('/'); }} className="w-full bg-white rounded-2xl p-4 shadow-sm border border-hill-cream flex items-center gap-3 text-left active:scale-[0.99] transition">
          <div className="w-9 h-9 rounded-xl bg-hill-blue/15 flex items-center justify-center"><MapPin size={18} className="text-hill-blue" /></div>
          <div className="flex-1">
            <div className="font-bold text-hill-deep text-sm">{t('changeSetup', lang)}</div>
            <div className="text-xs text-muted-foreground">{lang === 'hi' ? 'गाँव, फसल या अवस्था बदलें' : 'Change village, crop or stage'}</div>
          </div>
          <ChevronRight size={18} className="text-muted-foreground" />
        </button>

        {/* Clear history */}
        {history.length > 0 && (
          <button onClick={clearHistory} className="w-full bg-white rounded-2xl p-4 shadow-sm border border-hill-cream flex items-center gap-3 text-left active:scale-[0.99] transition">
            <div className="w-9 h-9 rounded-xl bg-destructive/10 flex items-center justify-center"><Trash2 size={18} className="text-destructive" /></div>
            <div className="flex-1">
              <div className="font-bold text-hill-deep text-sm">{lang === 'hi' ? 'अलर्ट इतिहास साफ़ करें' : 'Clear alert history'}</div>
              <div className="text-xs text-muted-foreground">{history.length} {lang === 'hi' ? 'अलर्ट' : 'alerts'}</div>
            </div>
          </button>
        )}

        {/* Disclaimer */}
        <Card icon={<ShieldAlert size={18} />} title={lang === 'hi' ? 'अस्वीकरण' : 'Disclaimer'}>
          <p className="text-xs text-muted-foreground leading-relaxed">{t('disclaimer', lang)}</p>
        </Card>

        {/* About */}
        <Card icon={<Info size={18} />} title={lang === 'hi' ? 'बारे में' : 'About'}>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {lang === 'hi'
              ? 'HillSense — पहाड़ी किसानों के लिए गाँव-स्तरीय मौसम जोखिम अलर्ट प्रणाली।'
              : 'HillSense — a village-level weather risk alert system for hill farmers.'}
          </p>
          <p className="text-[11px] text-muted-foreground mt-2">WarriorHacks 2.0 · Team: Yashica Singla, IIT Mandi</p>
        </Card>
      </div>
    </AppShell>
  );
}

function Card({ icon, title, children }) {
  return (
    <div className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream">
      <div className="flex items-center gap-2 text-hill-deep font-bold text-sm mb-3">{icon}{title}</div>
      {children}
    </div>
  );
}