import React, { useState, useEffect } from 'react';
import { MapContainer, TileLayer, CircleMarker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import AppShell from '@/components/hillsense/AppShell';
import { useApp } from '@/lib/AppContext';
import { t } from '@/lib/i18n';
import { base44 } from '@/api/base44Client';
import { CloudHail, Snowflake, Mountain } from 'lucide-react';

const HAZARDS = [
  { key: 'hail', icon: CloudHail },
  { key: 'frost', icon: Snowflake },
  { key: 'landslide', icon: Mountain }
];
const HAZARD_LABEL = { hail: { hi: 'ओले', en: 'Hail' }, frost: { hi: 'जाड़ा', en: 'Frost' }, landslide: { hi: 'भूस्खलन', en: 'Landslide' } };
const LEVEL_COLOR = { LOW: '#2E7D50', MEDIUM: '#F39C12', HIGH: '#E74C3C' };

export default function RiskMap() {
  const { language, district, village, crop, stage, demoScenario } = useApp();
  const lang = language;
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!district) return;
    let active = true;
    setLoading(true);
    base44.functions.invoke('getDistrictRisk', { district, crop, stage, demoScenario: demoScenario || 'off', lang })
      .then((r) => active && setData(r.data))
      .catch(() => {})
      .finally(() => active && setLoading(false));
    return () => { active = false; };
  }, [district, crop, stage, demoScenario, lang]);

  return (
    <AppShell title={t('riskMap', lang)} subtitle={district}>
      <div className="space-y-4">
        <div className="bg-hill-blue/10 border border-hill-blue/20 rounded-2xl p-3 text-xs text-hill-deep">
          {lang === 'hi'
            ? 'ज़िले के हर गाँव का जोखिम अलग — यही हाइपरलोकल चेतावनी का विचार है। रंग: हरा=कम, पीला=मध्यम, लाल=अधिक।'
            : 'Each village in the district has its own risk — this is the hyperlocal idea. Colours: green=low, amber=medium, red=high.'}
        </div>

        {/* Map */}
        <div className="rounded-2xl overflow-hidden shadow-sm border border-hill-cream h-64">
          {data ? (
            <MapContainer center={[data.center.lat, data.center.lon]} zoom={9} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false}>
              <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution='&copy; OpenStreetMap' />
              {data.villages.map((v) => (
                <CircleMarker
                  key={v.name}
                  center={[v.lat, v.lon]}
                  radius={16}
                  pathOptions={{ color: LEVEL_COLOR[v.highest.level], fillColor: LEVEL_COLOR[v.highest.level], fillOpacity: 0.7 }}
                >
                  <Popup>
                    <strong>{v.name}</strong><br />
                    {HAZARD_LABEL[v.highest.hazard][lang]}: {v.highest.percent}%
                  </Popup>
                </CircleMarker>
              ))}
            </MapContainer>
          ) : (
            <div className="h-full flex items-center justify-center text-muted-foreground text-sm">{loading ? '…' : ''}</div>
          )}
        </div>

        {/* Village grid */}
        <div className="grid grid-cols-2 gap-2.5">
          {(data?.villages || []).map((v) => {
            const isMine = v.name === village;
            return (
              <div key={v.name} className={`rounded-2xl p-3 shadow-sm border-2 ${isMine ? 'border-hill-deep bg-white' : 'border-hill-cream bg-white'}`}>
                <div className="flex items-center justify-between">
                  <div className="font-bold text-hill-deep text-sm">{v.name}</div>
                  <span className="w-3 h-3 rounded-full" style={{ background: LEVEL_COLOR[v.highest.level] }} />
                </div>
                <div className="text-[11px] text-muted-foreground mt-0.5">{v.altitude}m · {v.slope}°</div>
                <div className="mt-2 space-y-1">
                  {HAZARDS.map((h) => {
                    const Icon = h.icon;
                    const r = v.risk[h.key];
                    return (
                      <div key={h.key} className="flex items-center gap-1.5">
                        <Icon size={12} style={{ color: LEVEL_COLOR[r.level] }} />
                        <span className="text-[10px] text-muted-foreground flex-1">{HAZARD_LABEL[h.key][lang]}</span>
                        <span className="text-[10px] font-bold" style={{ color: LEVEL_COLOR[r.level] }}>{r.percent}%</span>
                      </div>
                    );
                  })}
                </div>
                {isMine && <div className="text-[10px] font-bold text-hill-deep mt-1.5">{lang === 'hi' ? 'आपका गाँव' : 'Your village'}</div>}
              </div>
            );
          })}
        </div>

        <p className="text-[11px] text-muted-foreground text-center px-2">{t('disclaimer', lang)}</p>
      </div>
    </AppShell>
  );
}