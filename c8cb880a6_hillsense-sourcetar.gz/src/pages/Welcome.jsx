import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '@/lib/AppContext';
import { t, LANGS } from '@/lib/i18n';
import { DISTRICTS, CROPS, STAGES } from '@/lib/hillData';
import Logo from '@/components/hillsense/Logo';
import { ChevronRight, MapPin, Sprout, CalendarHeart } from 'lucide-react';

export default function Welcome() {
  const { language, update, completeSetup } = useApp();
  const navigate = useNavigate();
  const lang = language;
  const [district, setDistrict] = useState('');
  const [village, setVillage] = useState('');
  const [crop, setCrop] = useState('Apple');
  const [stage, setStage] = useState('Fruit setting');

  const districtObj = DISTRICTS.find((d) => d.name === district);

  const canContinue = district && village;

  const handleContinue = () => {
    completeSetup({ district, village, crop, stage });
    navigate('/dashboard');
  };

  return (
    <div className="min-h-screen night-gradient flex flex-col">
      <div className="flex-1 max-w-md mx-auto w-full flex flex-col px-6 pt-12 pb-8">
        {/* Hero */}
        <div className="flex flex-col items-center text-center text-white mt-6 mb-8 animate-fade-in">
          <div className="relative mb-5">
            <div className="absolute inset-0 rounded-full bg-white/10 blur-2xl" />
            <Logo size={84} />
          </div>
          <h1 className="font-heading font-extrabold text-4xl tracking-tight">HillSense</h1>
          <p className="text-white/85 mt-2 text-lg font-medium">{t('tagline', lang)}</p>
          <div className="mt-5 bg-white rounded-full px-5 py-2.5 text-hill-deep font-semibold text-sm text-center max-w-xs">
            {lang === 'hi' ? 'पहाड़ी किसानों के लिए गाँव-स्तरीय ओले, जाड़ा और भूस्खलन अलर्ट' : 'Village-level hail, frost & landslide alerts for hill farmers'}
          </div>
        </div>

        {/* Setup card */}
        <div className="bg-white rounded-3xl shadow-xl p-5 flex-1 flex flex-col animate-pop-in">
          {/* Language */}
          <Section icon={null} label={t('chooseLanguage', lang)}>
            <div className="grid grid-cols-2 gap-2">
              {LANGS.map((l) => {
                const active = language === l.code;
                return (
                  <button
                    key={l.code}
                    onClick={() => update({ language: l.code })}
                    className={`rounded-2xl py-3 px-3 font-bold transition border-2 ${active ? 'bg-hill-deep text-white border-hill-deep' : 'bg-hill-cream text-hill-deep border-transparent'}`}
                  >
                    <div className="text-lg">{l.label}</div>
                    <div className={`text-xs font-medium ${active ? 'text-white/80' : 'text-muted-foreground'}`}>{l.sub}</div>
                  </button>
                );
              })}
            </div>
          </Section>

          {/* District */}
          <Section icon={<MapPin size={16} />} label={t('yourDistrict', lang)}>
            <Select value={district} onChange={(v) => { setDistrict(v); setVillage(''); }} options={DISTRICTS.map((d) => d.name)} placeholder={lang === 'hi' ? 'ज़िला चुनें' : 'Select district'} lang={lang} />
          </Section>

          {/* Village */}
          <Section icon={<MapPin size={16} />} label={t('yourVillage', lang)}>
            <Select
              value={village}
              onChange={setVillage}
              options={districtObj ? districtObj.villages : []}
              placeholder={districtObj ? (lang === 'hi' ? 'गाँव चुनें' : 'Select village') : (lang === 'hi' ? 'पहले ज़िला चुनें' : 'Select district first')}
              disabled={!districtObj}
              lang={lang}
            />
          </Section>

          {/* Crop */}
          <Section icon={<Sprout size={16} />} label={t('yourCrop', lang)}>
            <div className="grid grid-cols-2 gap-2">
              {CROPS.map((c) => (
                <Chip key={c} active={crop === c} onClick={() => setCrop(c)}>{c}</Chip>
              ))}
            </div>
          </Section>

          {/* Stage */}
          <Section icon={<CalendarHeart size={16} />} label={t('cropStage', lang)}>
            <div className="grid grid-cols-3 gap-2">
              {STAGES.map((s) => (
                <Chip key={s} active={stage === s} onClick={() => setStage(s)} small>{s}</Chip>
              ))}
            </div>
          </Section>

          <div className="mt-auto pt-4">
            <button
              disabled={!canContinue}
              onClick={handleContinue}
              className={`w-full rounded-2xl py-4 font-bold text-base flex items-center justify-center gap-2 transition ${canContinue ? 'bg-hill-blue text-white shadow-lg' : 'bg-muted text-muted-foreground'}`}
            >
              {t('continue', lang)} <ChevronRight size={20} />
            </button>
          </div>
        </div>

        <p className="text-white/70 text-[11px] text-center mt-4 leading-relaxed">
          {t('disclaimer', lang)}
        </p>
        <p className="text-white/60 text-[11px] text-center mt-1">WarriorHacks 2.0 · Team: Yashica Singla, IIT Mandi</p>
      </div>
    </div>
  );
}

function Section({ icon, label, children }) {
  return (
    <div className="mb-4">
      <div className="flex items-center gap-1.5 text-hill-deep font-bold text-sm mb-2">
        {icon}{label}
      </div>
      {children}
    </div>
  );
}

function Chip({ active, onClick, small, children }) {
  return (
    <button
      onClick={onClick}
      className={`rounded-xl ${small ? 'py-2 text-xs' : 'py-2.5 text-sm'} font-semibold transition border-2 ${active ? 'bg-hill-green text-white border-hill-green' : 'bg-hill-cream text-hill-deep border-transparent'}`}
    >
      {children}
    </button>
  );
}

function Select({ value, onChange, options, placeholder, disabled, lang }) {
  return (
    <select
      value={value}
      disabled={disabled}
      onChange={(e) => onChange(e.target.value)}
      className={`w-full rounded-2xl py-3 px-4 font-semibold text-hill-deep bg-hill-cream border-2 border-transparent focus:border-hill-green outline-none transition appearance-none ${disabled ? 'opacity-50' : ''}`}
    >
      <option value="" disabled>{placeholder}</option>
      {options.map((o) => (
        <option key={o} value={o}>{o}</option>
      ))}
    </select>
  );
}