import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useApp } from '@/lib/AppContext';
import { useVillageRisk } from '@/lib/useVillageRisk';
import { t } from '@/lib/i18n';
import { base44 } from '@/api/base44Client';
import { Snowflake, CloudHail, Mountain, Volume2, Check, MessageCircle, AlertTriangle, ArrowLeft } from 'lucide-react';

const HAZARD_ICON = { hail: CloudHail, frost: Snowflake, landslide: Mountain };
const HAZARD_LABEL = { hail: { hi: 'ओले (हेल)', en: 'Hail' }, frost: { hi: 'जाड़ा (फ्रॉस्ट)', en: 'Frost' }, landslide: { hi: 'भूस्खलन', en: 'Landslide' } };
const TIME_WINDOW = {
  hail: { hi: 'अगले कुछ घंटों में', en: 'In the next few hours' },
  frost: { hi: 'आज रात', en: 'Tonight' },
  landslide: { hi: 'अगले 24 घंटों में', en: 'In the next 24 hours' }
};

function buildWhy(hazard, data, lang) {
  if (!data) return '';
  const c = data.current;
  if (hazard === 'frost') {
    return lang === 'hi'
      ? `आज रात न्यूनतम तापमान ${c.tempMin}°C, बादल ${c.cloudCover}% और हवा धीमी — जाड़े के लिए आदर्श।`
      : `Tonight's minimum is ${c.tempMin}°C with ${c.cloudCover}% cloud and low wind — ideal for frost.`;
  }
  if (hazard === 'hail') {
    return lang === 'hi'
      ? `तापमान में अंतर ${c.tempMax - c.tempMin}°C, नमी ${c.humidity}% और गिरता दबाव — ओलों का जोखिम।`
      : `Temp range ${c.tempMax - c.tempMin}°C, humidity ${c.humidity}% and falling pressure — hail risk.`;
  }
  return lang === 'hi'
    ? `भारी बारिश (${c.rain} mm) और तीखी ढाल — भूस्खलन का जोखिम।`
    : `Heavy rainfall (${c.rain} mm) on steep slopes — landslide risk.`;
}

export default function AlertDetail() {
  const { hazard } = useParams();
  const { language, district, village, crop, stage, demoScenario, addAlert } = useApp();
  const lang = language;
  const navigate = useNavigate();
  const { data } = useVillageRisk({ district, village, crop, stage, demoScenario, lang });
  const [advice, setAdvice] = useState(null);
  const [hindiAdvice, setHindiAdvice] = useState(null);
  const [speaking, setSpeaking] = useState(false);

  const risk = data?.risk?.[hazard];
  const level = risk?.level || 'HIGH';
  const isHigh = level === 'HIGH';
  const Icon = HAZARD_ICON[hazard] || AlertTriangle;

  useEffect(() => {
    let active = true;
    base44.functions.invoke('getAlertAdvice', { hazard, crop, stage, lang, villageName: village, level })
      .then((r) => active && setAdvice(r.data)).catch(() => {});
    base44.functions.invoke('getAlertAdvice', { hazard, crop, stage, lang: 'hi', villageName: village, level })
      .then((r) => active && setHindiAdvice(r.data)).catch(() => {});
    return () => { active = false; };
  }, [hazard, crop, stage, lang, village, level]);

  const handleListen = () => {
    const text = hindiAdvice ? `${hindiAdvice.label}. ${hindiAdvice.steps.join('. ')}` : '';
    if (!text || !('speechSynthesis' in window)) return;
    const u = new SpeechSynthesisUtterance(text);
    u.lang = 'hi-IN';
    u.rate = 0.92;
    const voices = window.speechSynthesis.getVoices();
    const hi = voices.find((v) => v.lang && v.lang.toLowerCase().startsWith('hi'));
    if (hi) u.voice = hi;
    u.onstart = () => setSpeaking(true);
    u.onend = () => setSpeaking(false);
    window.speechSynthesis.cancel();
    window.speechSynthesis.speak(u);
  };

  useEffect(() => () => { if ('speechSynthesis' in window) window.speechSynthesis.cancel(); }, []);

  const handleGotIt = () => {
    if (risk && (level === 'HIGH' || level === 'MEDIUM')) {
      addAlert({
        hazard, level, percent: risk.percent, village, crop, stage,
        message: advice?.message || ''
      });
    }
    navigate('/dashboard');
  };

  const tone = isHigh ? 'bg-hill-high' : 'bg-hill-medium';

  return (
    <div className={`min-h-screen flex flex-col ${tone} text-white`}>
      <div className="max-w-md mx-auto w-full flex-1 flex flex-col px-5 pt-6 pb-8">
        {/* Alert header */}
        <div className="flex items-center justify-between">
          <button onClick={() => navigate('/dashboard')} className="p-2 -ml-2 text-white/90"><ArrowLeft size={24} /></button>
          <span className="text-sm font-bold uppercase tracking-widest bg-white/20 px-3 py-1 rounded-full">{t('viewAlert', lang)}</span>
        </div>

        <div className="flex flex-col items-center text-center mt-6 mb-6 animate-pop-in">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-white/30 animate-pulse-ring" />
            <div className="relative w-24 h-24 rounded-full bg-white/15 flex items-center justify-center">
              <Icon size={52} />
            </div>
          </div>
          <h1 className="font-heading font-extrabold text-3xl mt-4">{HAZARD_LABEL[hazard]?.[lang] || hazard}</h1>
          <div className="text-white/90 font-semibold mt-1">{TIME_WINDOW[hazard]?.[lang]}</div>
          {risk && (
            <div className="mt-2 bg-white/20 rounded-full px-4 py-1 text-sm font-bold">
              {t(level.toLowerCase(), lang)} · {risk.percent}%
            </div>
          )}
        </div>

        {/* Why */}
        <div className="bg-white/15 rounded-2xl p-4 mb-4">
          <div className="text-xs font-bold uppercase tracking-wide text-white/70 mb-1">{t('why', lang)}</div>
          <p className="text-sm font-medium leading-relaxed">{buildWhy(hazard, data, lang)}</p>
        </div>

        {/* What to do */}
        <div className="bg-white rounded-3xl p-5 text-hill-deep shadow-xl flex-1">
          <div className="text-xs font-bold uppercase tracking-wide text-hill-green mb-3">{t('whatToDo', lang)}</div>
          {advice ? (
            <ol className="space-y-3">
              {advice.steps.map((step, i) => (
                <li key={i} className="flex gap-3">
                  <span className="w-7 h-7 rounded-full bg-hill-green text-white font-bold text-sm flex items-center justify-center shrink-0">{i + 1}</span>
                  <span className="font-medium leading-snug pt-0.5">{step}</span>
                </li>
              ))}
            </ol>
          ) : (
            <div className="space-y-2">{[0, 1, 2].map((i) => <div key={i} className="h-5 rounded bg-hill-cream animate-pulse" />)}</div>
          )}
        </div>

        {/* Actions */}
        <div className="space-y-2.5 mt-5">
          <button
            onClick={handleGotIt}
            className="w-full rounded-2xl py-4 bg-hill-deep text-white font-bold text-base flex items-center justify-center gap-2 shadow-lg active:scale-[0.99] transition"
          >
            <Check size={22} /> {t('gotIt', lang)}
          </button>
          <div className="grid grid-cols-2 gap-2.5">
            <button
              onClick={handleListen}
              className="rounded-2xl py-3.5 border-2 border-white font-bold text-sm flex items-center justify-center gap-2 active:scale-[0.99] transition"
            >
              <Volume2 size={18} className={speaking ? 'animate-pulse' : ''} /> {t('listenHindi', lang)}
            </button>
            <button
              onClick={() => navigate('/whatsapp')}
              className="rounded-2xl py-3.5 border-2 border-white font-bold text-sm flex items-center justify-center gap-2 active:scale-[0.99] transition"
            >
              <MessageCircle size={18} /> WhatsApp
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}