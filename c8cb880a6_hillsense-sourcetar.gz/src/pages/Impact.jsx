import React from 'react';
import AppShell from '@/components/hillsense/AppShell';
import { useApp } from '@/lib/AppContext';
import { t } from '@/lib/i18n';
import { Sprout, ShieldCheck, HeartPulse, Cpu, Mic, Map, Leaf } from 'lucide-react';

export default function Impact() {
  const { language } = useApp();
  const lang = language;

  const impacts = [
    { icon: Sprout, title: lang === 'hi' ? 'आजीविका बचाता है' : 'Protects livelihoods', text: lang === 'hi' ? 'कुछ घंटों की चेतावनी साल भर की कमाई बचा सकती है।' : 'A few hours of warning can save a year of income.' },
    { icon: HeartPulse, title: lang === 'hi' ? 'जान बचाता है' : 'Protects lives', text: lang === 'hi' ? 'भूस्खलन अलर्ट परिवारों को सुरक्षित रखते हैं।' : 'Landslide alerts keep families safe.' },
    { icon: ShieldCheck, title: lang === 'hi' ? 'जलवायु लचीलापन' : 'Climate resilience', text: lang === 'hi' ? 'पहाड़ी किसानों के लिए बदलते मौसम से निपटने का साधन।' : 'A tool for hill farmers to face changing weather.' },
    { icon: Cpu, title: lang === 'hi' ? 'कोई नया ऐप नहीं' : 'Needs no new app', text: lang === 'hi' ? 'बस एक फ़ोन चाहिए — WhatsApp या SMS।' : 'Only a basic phone — WhatsApp or SMS.' }
  ];

  const future = [
    { icon: Cpu, text: lang === 'hi' ? 'सस्ते गाँव-स्तरीय सेंसर' : 'Low-cost village sensors' },
    { icon: Leaf, text: lang === 'hi' ? 'और फसलें: चेरी, प्लम, सब्ज़ियाँ' : 'More crops: cherry, plum, vegetables' },
    { icon: Mic, text: lang === 'hi' ? 'पढ़ने न जानने वालों के लिए आवाज़ अलर्ट' : 'Voice alerts for non-readers' },
    { icon: Map, text: lang === 'hi' ? 'उत्तराखंड, जेके, पूर्वोत्तर तक विस्तार' : 'Expand to Uttarakhand, J&K, Northeast' },
    { icon: ShieldCheck, text: lang === 'hi' ? 'राज्य बागवानी विभाग से जुड़ना' : 'Link with state horticulture dept.' }
  ];

  return (
    <AppShell title={t('impact', lang)}>
      <div className="space-y-4">
        <div className="night-gradient rounded-3xl p-5 text-white text-center">
          <h2 className="font-heading font-extrabold text-xl">{lang === 'hi' ? 'अलर्ट क्यों मायने रखते हैं' : 'Why these alerts matter'}</h2>
          <p className="text-white/85 text-sm mt-1.5">{lang === 'hi' ? 'हिमाचल के पहाड़ी किसानों के लिए एक बुरी रात पूरी सीज़न बर्बाद कर सकती है।' : 'For hill farmers in Himachal, one bad night can end a whole season.'}</p>
        </div>

        <div className="grid grid-cols-2 gap-2.5">
          {impacts.map((it) => {
            const Icon = it.icon;
            return (
              <div key={it.title} className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream">
                <div className="w-10 h-10 rounded-2xl bg-hill-green/15 flex items-center justify-center mb-2">
                  <Icon size={20} className="text-hill-green" />
                </div>
                <div className="font-bold text-hill-deep text-sm leading-tight">{it.title}</div>
                <div className="text-xs text-muted-foreground mt-1 leading-snug">{it.text}</div>
              </div>
            );
          })}
        </div>

        <div className="bg-white rounded-2xl p-5 shadow-sm border border-hill-cream">
          <h3 className="font-bold text-hill-deep mb-3 flex items-center gap-2"><Sprout size={18} className="text-hill-green" /> {t('futureScope', lang)}</h3>
          <ul className="space-y-2.5">
            {future.map((f, i) => {
              const Icon = f.icon;
              return (
                <li key={i} className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-hill-cream flex items-center justify-center shrink-0">
                    <Icon size={16} className="text-hill-deep" />
                  </div>
                  <span className="text-sm font-medium text-hill-deep">{f.text}</span>
                </li>
              );
            })}
          </ul>
        </div>

        <p className="text-[11px] text-muted-foreground text-center px-2">{t('disclaimer', lang)}</p>
      </div>
    </AppShell>
  );
}