import React from 'react';
import { useApp } from '@/lib/AppContext';
import Welcome from './Welcome';
import Dashboard from './Dashboard';

export default function Root() {
  const { setupComplete } = useApp();
  return setupComplete ? <Dashboard /> : <Welcome />;
}