import React from 'react';
import AppShell from '@/components/hillsense/AppShell';
import { useApp } from '@/lib/AppContext';
import { useVillageRisk } from '@/lib/useVillageRisk';
import { t } from '@/lib/i18n';
import { Cloud, Database, BrainCircuit, MessageSquare, Smartphone, FlaskConical } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell } from 'recharts';

const STEPS = [
  { icon: Cloud, title: '1 · Collect', text: 'Weather API data (Open-Meteo) for each village' },
  { icon: Database, title: '2 · Process', text: 'Clean data, add terrain & crop-stage features' },
  { icon: BrainCircuit, title: '3 · Predict', text: 'Gradient-Boosting-style model scores hail, frost & landslide risk' },
  { icon: MessageSquare, title: '4 · Alert', text: 'Hindi SMS / WhatsApp with crop advice' },
  { icon: Smartphone, title: '5 · Act', text: 'Farmer protects crops and family in time' }
];

export default function ModelInfo() {
  const { language, district, village, crop, stage, demoScenario } = useApp();
  const lang = language;
  const { data } = useVillageRisk({ district, village, crop, stage, demoScenario, lang });

  const accuracy = data?.modelInfo?.accuracy;
  const importance = data?.modelInfo?.featureImportance || [];
  const chartData = importance.map((f) => ({ name: f.feature, value: f.importance }));
  const CONTRIB_COLORS = ['#14463A', '#2E7D50', '#2980B9', '#F39C12'];

  return (
    <AppShell title={t('modelInfo', lang)}>
      <div className="space-y-4">
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream">
          <h2 className="font-bold text-hill-deep flex items-center gap-2 mb-1"><FlaskConical size={18} className="text-hill-green" /> {lang === 'hi' ? 'जोखिम इंजन' : 'Risk engine'}</h2>
          <p className="text-xs text-muted-foreground leading-relaxed">
            {lang === 'hi'
              ? 'यह एक प्रोटोटाइप मॉडल है जो नियम-आधारित कृत्रिम डेटासेट पर सिखाया गया है — असली IMD पूर्वानुमान नहीं।'
              : 'A prototype model trained on a synthetic rule-based dataset — not a real IMD forecast.'}
          </p>
        </div>

        {/* Accuracy */}
        {accuracy && (
          <div className="grid grid-cols-3 gap-2.5">
            {['frost', 'hail', 'landslide'].map((h, i) => (
              <div key={h} className="bg-white rounded-2xl p-3 text-center shadow-sm border border-hill-cream">
                <div className="text-2xl font-extrabold" style={{ color: CONTRIB_COLORS[i] }}>{Math.round(accuracy[h] * 100)}%</div>
                <div className="text-[11px] text-muted-foreground capitalize mt-0.5">{h}</div>
              </div>
            ))}
          </div>
        )}
        {accuracy && <p className="text-[11px] text-muted-foreground text-center -mt-1">{accuracy.note}</p>}

        {/* Feature importance */}
        {chartData.length > 0 && (
          <div className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream">
            <h3 className="font-bold text-hill-deep text-sm mb-2">{lang === 'hi' ? 'फ़ीचर महत्व' : 'Feature importance'}</h3>
            <div className="h-56">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} layout="vertical" margin={{ top: 0, right: 16, left: 0, bottom: 0 }}>
                  <XAxis type="number" domain={[0, 0.3]} hide />
                  <YAxis type="category" dataKey="name" tick={{ fontSize: 11, fill: '#334155' }} width={92} axisLine={false} tickLine={false} />
                  <Tooltip cursor={{ fill: 'rgba(0,0,0,0.04)' }} contentStyle={{ borderRadius: 12, border: 'none', fontSize: 12 }} />
                  <Bar dataKey="value" radius={[0, 6, 6, 0]} maxBarSize={18}>
                    {chartData.map((_, i) => <Cell key={i} fill={CONTRIB_COLORS[i % CONTRIB_COLORS.length]} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>
        )}

        {/* How it works */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-hill-cream">
          <h3 className="font-bold text-hill-deep text-sm mb-3">{lang === 'hi' ? 'कैसे काम करता है' : 'How it works'}</h3>
          <div className="space-y-2.5">
            {STEPS.map((s) => {
              const Icon = s.icon;
              return (
                <div key={s.title} className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-hill-green/15 flex items-center justify-center shrink-0">
                    <Icon size={18} className="text-hill-green" />
                  </div>
                  <div>
                    <div className="font-bold text-hill-deep text-sm">{s.title}</div>
                    <div className="text-xs text-muted-foreground leading-snug">{s.text}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        <p className="text-[11px] text-muted-foreground text-center px-2">{t('disclaimer', lang)}</p>
      </div>
    </AppShell>
  );
}