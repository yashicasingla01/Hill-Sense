import React from 'react';
import { t } from '@/lib/i18n';

const STYLES = {
  LOW: { bg: 'bg-hill-low', text: 'text-white', dot: 'bg-white' },
  MEDIUM: { bg: 'bg-hill-medium', text: 'text-white', dot: 'bg-white' },
  HIGH: { bg: 'bg-hill-high', text: 'text-white', dot: 'bg-white' }
};

export default function RiskPill({ level, lang, size = 'md' }) {
  const s = STYLES[level] || STYLES.LOW;
  const sizes = size === 'sm' ? 'text-[11px] px-2 py-0.5' : 'text-sm px-3 py-1';
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full font-bold ${s.bg} ${s.text} ${sizes}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${s.dot}`} />
      {t(level.toLowerCase(), lang)}
    </span>
  );
}