import React from 'react';

export default function Logo({ size = 40, withText = false, light = false }) {
  return (
    <div className="flex items-center gap-2">
      <svg width={size} height={size} viewBox="0 0 64 64" fill="none" xmlns="http://www.w3.org/2000/svg">
        <defs>
          <linearGradient id="hg" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#1E4562" />
            <stop offset="1" stopColor="#14463A" />
          </linearGradient>
        </defs>
        <rect width="64" height="64" rx="16" fill="url(#hg)" />
        <circle cx="47" cy="17" r="6" fill="#FFDE69" />
        <path d="M5 49 L23 21 L33 35 L39 27 L59 49 Z" fill="#FFFFFF" />
        <path d="M5 49 L23 21 L29 30 L17 49 Z" fill="#2E7D50" />
        <path d="M27 25 L23 21 L19 27 L23 29 Z" fill="#FFFFFF" opacity="0.9" />
      </svg>
      {withText && (
        <span className={`font-heading font-extrabold tracking-tight ${light ? 'text-white' : 'text-hill-deep'}`} style={{ fontSize: size * 0.5 }}>
          HillSense
        </span>
      )}
    </div>
  );
}