import React from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Home, CalendarDays, Map as MapIcon, History as HistoryIcon, Sparkles, Settings, FlaskConical } from 'lucide-react';
import { useApp } from '@/lib/AppContext';
import { t } from '@/lib/i18n';
import Logo from './Logo';
import DemoBar from './DemoBar';

const NAV = [
  { to: '/dashboard', icon: Home, key: 'home' },
  { to: '/forecast', icon: CalendarDays, key: 'forecast' },
  { to: '/map', icon: MapIcon, key: 'riskMap' },
  { to: '/history', icon: HistoryIcon, key: 'alertHistory' },
  { to: '/impact', icon: Sparkles, key: 'impact' }
];

export default function AppShell({ children, title, subtitle, alertTone }) {
  const { language, village } = useApp();
  const location = useLocation();
  const navigate = useNavigate();
  const lang = language;

  return (
    <div className="min-h-screen bg-hill-cream flex flex-col">
      <header
        className={`sticky top-0 z-30 px-4 pt-3 pb-3 shadow-sm ${alertTone ? 'bg-destructive text-white' : 'bg-hill-deep text-white'}`}
      >
        <div className="max-w-md mx-auto flex items-center justify-between gap-3">
          <div className="flex items-center gap-2 min-w-0">
            <Logo size={34} />
            <div className="min-w-0">
              <div className="font-heading font-bold text-base leading-tight truncate">
                {title || village || t('appName', lang)}
              </div>
              {subtitle && <div className="text-xs text-white/80 leading-tight truncate">{subtitle}</div>}
            </div>
          </div>
          <div className="flex items-center gap-1">
            <button
              onClick={() => navigate('/model')}
              className="p-2 rounded-full hover:bg-white/10 transition"
              aria-label={t('modelInfo', lang)}
            >
              <FlaskConical size={20} />
            </button>
            <button
              onClick={() => navigate('/settings')}
              className="p-2 rounded-full hover:bg-white/10 transition"
              aria-label={t('settings', lang)}
            >
              <Settings size={20} />
            </button>
          </div>
        </div>
      </header>

      <DemoBar />

      <main className={`flex-1 max-w-md mx-auto w-full px-4 py-4 ${useApp().largeText ? 'large-text' : ''}`}>
        {children}
      </main>

      <nav className="sticky bottom-0 z-30 bg-white border-t border-hill-cream shadow-[0_-2px_10px_rgba(0,0,0,0.04)]">
        <div className="max-w-md mx-auto grid grid-cols-5">
          {NAV.map((item) => {
            const active = location.pathname === item.to;
            const Icon = item.icon;
            return (
              <Link
                key={item.to}
                to={item.to}
                className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] font-semibold transition ${active ? 'text-hill-deep' : 'text-muted-foreground'}`}
              >
                <Icon size={22} strokeWidth={active ? 2.6 : 2} />
                <span>{t(item.key, lang)}</span>
              </Link>
            );
          })}
        </div>
      </nav>
    </div>
  );
}