import React from 'react';
import { useApp } from '@/lib/AppContext';
import { t } from '@/lib/i18n';
import { FlaskConical, X } from 'lucide-react';

const SCENARIOS = [
  { code: 'off', key: 'demoOff' },
  { code: 'hailstorm', key: 'hailstorm' },
  { code: 'frostnight', key: 'frostnight' },
  { code: 'heavyrain', key: 'heavyrain' }
];

export default function DemoBar() {
  const { demoScenario, update, language } = useApp();
  const lang = language;
  const open = demoScenario && demoScenario !== 'off';

  return (
    <div className={`bg-hill-cream/80 border-b border-hill-cream transition-all ${open ? 'py-2' : 'py-1.5'}`}>
      <div className="max-w-md mx-auto px-4 flex items-center gap-2 overflow-x-auto no-scrollbar">
        <div className="flex items-center gap-1.5 text-hill-deep shrink-0">
          <FlaskConical size={15} />
          <span className="text-xs font-bold uppercase tracking-wide">{t('demoMode', lang)}</span>
        </div>
        <div className="flex gap-1.5 ml-auto">
          {SCENARIOS.map((s) => {
            const active = demoScenario === s.code;
            return (
              <button
                key={s.code}
                onClick={() => update({ demoScenario: s.code })}
                className={`px-3 py-1 rounded-full text-xs font-semibold whitespace-nowrap transition ${
                  active ? 'bg-hill-deep text-white shadow' : 'bg-white text-hill-deep border border-hill-cream'
                }`}
              >
                {t(s.key, lang)}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}