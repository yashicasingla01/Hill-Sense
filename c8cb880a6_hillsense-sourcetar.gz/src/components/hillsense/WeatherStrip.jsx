import React from 'react';
import { Thermometer, Droplets, Wind, CloudRain } from 'lucide-react';
import { t } from '@/lib/i18n';

export default function WeatherStrip({ current, lang }) {
  if (!current) return null;
  const items = [
    { icon: Thermometer, label: t('temp', lang), value: `${current.temp}°C` },
    { icon: Droplets, label: t('humidity', lang), value: `${current.humidity}%` },
    { icon: Wind, label: t('wind', lang), value: `${current.wind} km/h` },
    { icon: CloudRain, label: t('rainfall', lang), value: `${current.rain} mm` }
  ];
  return (
    <div className="grid grid-cols-4 gap-2">
      {items.map((it) => {
        const Icon = it.icon;
        return (
          <div key={it.label} className="bg-white rounded-2xl p-2.5 flex flex-col items-center text-center shadow-sm border border-hill-cream">
            <Icon size={18} className="text-hill-blue mb-1" />
            <div className="text-sm font-bold text-hill-deep leading-tight">{it.value}</div>
            <div className="text-[10px] text-muted-foreground leading-tight">{it.label}</div>
          </div>
        );
      })}
    </div>
  );
}